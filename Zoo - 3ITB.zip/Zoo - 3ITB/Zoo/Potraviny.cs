﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    internal class Potraviny
    {
        public string nazev { get; }
        public float mnozstvi { get; set; }
        public Potraviny(string nazev, float mnozstvi)
        {
            this.nazev = nazev;
            this.mnozstvi = mnozstvi;
            Sklad.potravinySklad.Add(this);
        }
    }
}
//┌( ͡° ͜ʖ ͡°)=ε/̵͇̿̿/’̿’̿ ̿ G U N
