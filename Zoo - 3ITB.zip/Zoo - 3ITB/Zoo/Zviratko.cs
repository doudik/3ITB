﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    internal class Zviratko
    {
        //[Zvířátko]
        //jmeno, druhZvirete, pohlavi
        //List<Potravina> coPapa
        //rodič

        //opečovávatel?
        private string jmeno;
        private string druhZvirete;
        private bool pohlavi; //false - žena | true - muž
        public bool maHlad { get; set; }
        public List<Potraviny> coPapam = new List<Potraviny>();
        public Zviratko(string jmeno, string druhZvirete, bool pohlavi, List<Potraviny> coPapam) { 
            this.jmeno = jmeno;
            this.druhZvirete = druhZvirete;
            this.pohlavi = pohlavi;
            maHlad = false;
            this.coPapam = coPapam;
        }
    }
}