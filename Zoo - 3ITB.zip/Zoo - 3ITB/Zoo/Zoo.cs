﻿//ahoj
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    internal class Zoo
    {
        //List<Návštěvník>
        //jmeno, velikost, vstupne, kapacita, otevreno
        string jmeno;
        float velikost;
        public float vstupne { get; }
        public int kapacita { get; set; }
        public bool otevreno { get; }
        public List<Navstevnik> listNavstevniku = new List<Navstevnik>();

        public Zoo(string jmeno, float velikost, float vstupne, int kapacita, bool otevreno)
        {
            this.jmeno = jmeno;
            this.velikost = velikost;
            this.vstupne = vstupne;
            this.kapacita = kapacita;
            this.otevreno = otevreno;
        }    
    }
}