﻿namespace KradeniZviratek{ 
    class Program {
        static void Main(string[] args) {
            /*
             * Auto
             * Zviratko
             * Policista
             * Hranice
             * 
             * kupec?
             */
        }
    }
} 
