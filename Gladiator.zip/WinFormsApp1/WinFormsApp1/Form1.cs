namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /*
         * TODO
         * [GLADIATOR]
         * bool jeHezkej;
         * int sila, hp, zbroj, stamina
         * string jmeno;
         * int obratnost;
         * [ARENA]
         * List<Gladiator>
         * traps?           N�hodn� �ance na dmg?
         * [COMBAT]
         * Utok(Gladiator A, Gladiator B)
         * RegeneraceStaminy()
         * Obrana()
         * VyhnutiUtoku()
         * [LEADERBOARD]
         * List<Gladiator>
         * int rank;
         */
    }
}