﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class Combat : ICombat
    {
        //    [COMBAT]
        //     * Utok(Gladiator A, Gladiator B)
        //     * RegeneraceStaminy()
        //     * Obrana()
        //     * VyhnutiUtoku()

    }
    //nechceme to spis udělat jako interface? 
}
