﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class Gladiator
    {
        //[GLADIATOR]
        bool jeHezkej;
        int sila, hp, zbroj, stamina, utok;
        public int Zbroj {get {return zbroj;} }
        public int Hp { get { return hp;  } set { hp = value; } }
        public int Utok { get { return utok; } }
        string jmeno;
        int obratnost;
        public int Obratnost { get { return obratnost; } }

        public Gladiator(string jmeno, int sila, int hp, int zbroj, int stamina,  int obratnost)
        {
            
            this.jeHezkej = false;
            this.sila = sila;
            utok = sila * 10;
            this.hp = hp;
            this.zbroj = zbroj;
            this.stamina = stamina;
            this.jmeno = jmeno;
            this.obratnost = obratnost;
            Arena.gladiatorList.Add(this);
        }

    }
}
