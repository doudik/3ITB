﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class Arena
    {
        public static List<Gladiator> gladiatorList = new List<Gladiator>();
        static Random rnd = new Random();
        // [ARENA]
        //* List<Gladiator>
        //* traps?
        private string jmeno;
        public Arena(string jmeno) {
            this.jmeno = jmeno;
        }

        public static bool SlaplDoTrapy(Gladiator gladiator)
        {
            return 35 - gladiator.Obratnost < rnd.Next(100);
            
            
        }
        
    } 
}
