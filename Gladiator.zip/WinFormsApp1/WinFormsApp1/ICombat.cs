﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal interface ICombat
    {

        //[COMBAT]
        // * Utok(Gladiator A, Gladiator B)
        // * RegeneraceStaminy()
        // * Obrana()
        // * VyhnutiUtoku()
        
        //JEN NOTE, NENÍ PRO VÁS. PŘÍŠTÍ HODINU TO UDĚLÁME SPOLU
        //TODO DODĚLAT TO, VYMYSLET JINÝ ZPŮSOB JAK TO UDĚLAT --> NEJLÉPE ZNOVU PŘEPSAT
        public virtual Gladiator Souboj(Gladiator A, Gladiator B)
        {
            Random rnd = new Random();
            while (B.Hp > 0 && A.Hp > 0)
            {
                if (Arena.SlaplDoTrapy(A))
                {
                    A.Hp -= rnd.Next((int)(A.Hp / 30), (int)(A.Hp / 10));
                    Utok(A, B, true);
                }
                else {
                    Utok(A, B, false);
                }
                if (Arena.SlaplDoTrapy(B))
                {
                    B.Hp -= rnd.Next((int)(B.Hp / 30), (int)(B.Hp / 10));
                    Utok(A, B, true);
                }
                else
                {
                    Utok(A, B, false);
                }
            }
            return null;
        }
        public virtual Gladiator Utok(Gladiator A, Gladiator B, bool slapl) {
            while (B.Hp > 0 && A.Hp > 0)
            {
                // A utoci na B
                if (B.Hp > 0 && !slapl)
                {
                    B.Hp -= A.Utok - B.Zbroj;
                }
                else if (B.Hp > 0 && slapl)
                {
                    
                    B.Hp -= (((A.Utok) / 50) - B.Zbroj);
                }
                else {
                    //vyhrál gladiátor A
                    return A;
                }
                // ---------
                // B utoci na A
                if (A.Hp > 0 && !slapl)
                {
                    A.Hp -= B.Utok - A.Zbroj;
                }
                else if (A.Hp > 0 && slapl)
                {

                    A.Hp -= (((B.Utok) / 50) - A.Zbroj);
                }
                else
                {
                    //vyhrál gladiátor A
                    return B;
                }
            }
            return null;
        }
    }
}

